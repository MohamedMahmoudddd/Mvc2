using DY2MVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DY2MVC.Controllers
{
    public class HomeController : Controller
    {
        
        

        public IActionResult Privacy()
        {
            return View();
        }

    }
}
