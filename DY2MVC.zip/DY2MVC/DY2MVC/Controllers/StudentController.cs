﻿using DY2MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace DY2MVC.Controllers
{
    public class StudentController:Controller
    {
        // /Student/ShowAll
        public IActionResult ShowAll()
        {
            StudentBl studentBl = new StudentBl();
            List<Student> stud = studentBl.GetAll();
            return View("ShowAll",stud);
        }
        // /Student/Details?id=3
        public IActionResult Details(int id)
        {
            StudentBl studentBl = new StudentBl();
            Student Stud= studentBl.GetById(id);
            return View("Details",Stud);
        }
    }
}
