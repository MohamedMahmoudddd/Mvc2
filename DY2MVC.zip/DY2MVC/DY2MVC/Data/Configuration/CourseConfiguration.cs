﻿using DY2MVC.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DY2MVC.Data.Configuration
{
    public class CourseConfiguration : IEntityTypeConfiguration<Course>
    {
        public void Configure(EntityTypeBuilder<Course> builder)
        {
            builder.ToTable("Courses");
            builder.HasKey(C=>C.Id);
            builder.Property(C=>C.Name)
                .HasMaxLength(50);
            builder.HasMany(C => C.Teachers)
                .WithOne(T => T.Course)
                .HasForeignKey(T => T.CourseId);

        }
    }
}
