﻿using DY2MVC.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DY2MVC.Data.Configuration
{
    public class DepartmentConfiguration : IEntityTypeConfiguration<Department>
    {
        public void Configure(EntityTypeBuilder<Department> builder)
        {
            builder.ToTable("Departments");
            builder.HasKey(D => D.Id);
            builder.Property(D => D.Name)
                .IsRequired()
                .HasMaxLength(100);
            builder.HasMany(D => D.Students)
                .WithOne(S => S.Department)
                .HasForeignKey(S => S.DepartmentId);

            builder.HasMany(D => D.Teachers)
                .WithOne(T => T.Department)
                .HasForeignKey(T => T.DepartmentId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.HasMany(D => D.Courses)
                .WithOne(C => C.Department)
                .HasForeignKey(C => C.DepartmentId);


        }
    }
}
