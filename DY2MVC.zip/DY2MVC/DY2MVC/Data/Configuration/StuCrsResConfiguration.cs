﻿namespace DY2MVC.Data.Configuration
{

   
    using global::DY2MVC.Models;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    namespace DY2MVC.Data.Configurations
    {
        public class StuCrsResConfiguration : IEntityTypeConfiguration<StuCrsRes>
        {
            public void Configure(EntityTypeBuilder<StuCrsRes> builder)
            {
                builder.ToTable("StuCrsRes");

                builder.HasKey(sc => new { sc.StudentId, sc.CourseId });

                
                builder.HasOne(sc => sc.Student)
                       .WithMany(s => s.StuCrsRes)
                       .HasForeignKey(sc => sc.StudentId)
                       .OnDelete(DeleteBehavior.NoAction);

                
                builder.HasOne(sc => sc.Course)
                       .WithMany(c => c.StuCrsRes)
                       .HasForeignKey(sc => sc.CourseId)
                       .OnDelete(DeleteBehavior.NoAction);
            }
        }
    }
}
