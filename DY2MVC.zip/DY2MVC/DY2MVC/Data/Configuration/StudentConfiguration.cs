﻿using DY2MVC.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DY2MVC.Data.Configuration
{
    public class StudentConfiguration : IEntityTypeConfiguration<Student>
    {
        public void Configure(EntityTypeBuilder<Student> builder)
        {
            builder.ToTable("Students");
            builder.HasKey(S => S.Id);
            builder.Property(S=>S.Name)
                .IsRequired()
                .HasMaxLength(50);

            
        }
    }
}
