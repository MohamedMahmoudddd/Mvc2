﻿namespace DY2MVC.Models
{
    public class StuCrsRes
    {
        public int CourseId { get; set; }
        public int StudentId { get; set; }
        public int Grade { get; set; }
         public Course? Course { get; set; }
         public Student? Student { get; set; }
    }
}
