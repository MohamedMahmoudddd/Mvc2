﻿using DY2MVC.Data;
using Microsoft.EntityFrameworkCore;

namespace DY2MVC.Models
{
    public class StudentBl
    {
        SchoolDbContext context = new SchoolDbContext();
        public List<Student> GetAll()
        {
            return context.Students.Include(S=>S.Department).ToList();
        }
        public Student GetById(int id)
        {
            return context.Students
                .FirstOrDefault(S => S.Id == id);
        }
    }
}
