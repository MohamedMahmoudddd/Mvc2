﻿namespace DY2MVC.Models
{
    public class Teacher
    {
        public int Id { get; set; }
        public int DepartmentId { get; set; }
        public int CourseId { get; set; }
     
        public string? Name { get; set; }
        public string? Address { get; set; }

        public int Salary { get; set; }
        public Department Department { get; set; }
        public Course Course { get; set; }
    }
}
